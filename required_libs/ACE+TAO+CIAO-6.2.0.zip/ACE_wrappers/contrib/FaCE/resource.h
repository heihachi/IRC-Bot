// $Id: resource.h 91743 2010-09-13 18:24:51Z johnnyw $

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FaCE.rc
//
#define IDS_APP_TITLE                   1
#define IDC_FACE                        3
#define IDI_FACE                        101
#define IDM_MENU                        102
#define IDD_ABOUTBOX                    103
#define IDS_HELP                        104
#define IDD_CMDLINE                     104
#define IDD_OUTFILE                     105
#define IDD_ERRFILE                     107
#define IDD_FILEEXIST                   109
#define IDB_ACERACER                    113
#define IDB_TAO                         114
#define IDS_COMMAND1                    301
#define IDC_CMDEDIT                     1001
#define IDC_SAVEFILE                    1002
#define IDC_ERRFILE                     1003
#define IDOVERWRITE                     1004
#define IDC_APPEND                      1005
#define IDC_COPYRIGHT                   1007
#define IDC_TAO                         1008
#define IDM_MAIN_COMMAND1               40001
#define IDM_HELP_ABOUT                  40003
#define ID_SETTING                      40004
#define IDS_CAP_SETTING                 40006
#define ID_SETTING_COMMANDLINE          40007
#define ID_SETTING_RUN                  40008
#define ID_SETTING_EXIT                 40011
#define ID_TOOLS_SAVETOFILE             40012

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
