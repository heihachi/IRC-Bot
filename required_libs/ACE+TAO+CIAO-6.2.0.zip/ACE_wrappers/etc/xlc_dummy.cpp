// $Id: xlc_dummy.cpp 80826 2008-03-04 14:51:23Z wotte $
//
// This file exists only to help with template instantiation when building
// shared libraries on AIX using C Set++.  See rules.lib.GNU for usage.

/* FUZZ: disable check_for_improper_main_declaration */

main() {}
