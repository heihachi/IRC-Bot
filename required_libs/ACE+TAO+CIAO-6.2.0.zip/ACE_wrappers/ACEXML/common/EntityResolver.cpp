// $Id: EntityResolver.cpp 91673 2010-09-08 18:49:47Z johnnyw $

#include "EntityResolver.h"

ACEXML_EntityResolver::~ACEXML_EntityResolver (void)
{
}
