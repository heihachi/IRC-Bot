// $Id: Attributes.cpp 91673 2010-09-08 18:49:47Z johnnyw $

#include "Attributes.h"

ACEXML_Attributes::~ACEXML_Attributes (void)
{
}
