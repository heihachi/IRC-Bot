// $Id: Validator.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ACEXML/common/Validator.h"

ACEXML_Validator::~ACEXML_Validator ()
{

}
