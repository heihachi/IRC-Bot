// $Id: ContentHandler.cpp 91673 2010-09-08 18:49:47Z johnnyw $

#include "ContentHandler.h"

ACEXML_ContentHandler::~ACEXML_ContentHandler (void)
{
}
