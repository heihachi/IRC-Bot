// $Id: Element_Def_Builder.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ACEXML/common/Element_Def_Builder.h"

ACEXML_Element_Def_Builder::~ACEXML_Element_Def_Builder ()
{

}

