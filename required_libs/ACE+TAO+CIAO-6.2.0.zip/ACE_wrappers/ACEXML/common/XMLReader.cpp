// $Id: XMLReader.cpp 91673 2010-09-08 18:49:47Z johnnyw $

#include "XMLReader.h"

ACEXML_XMLReader::~ACEXML_XMLReader (void)
{
}
