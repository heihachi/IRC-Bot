// -*- C++ -*-  $Id: CharStream.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ACEXML/common/CharStream.h"

ACEXML_CharStream::~ACEXML_CharStream (void)
{
}
