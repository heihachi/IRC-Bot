// $Id: DTDHandler.cpp 91673 2010-09-08 18:49:47Z johnnyw $

#include "DTDHandler.h"

ACEXML_DTDHandler::~ACEXML_DTDHandler (void)
{
}
