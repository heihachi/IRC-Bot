// $Id: Attributes_Def_Builder.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ACEXML/common/Attributes_Def_Builder.h"

ACEXML_Attribute_Def_Builder::~ACEXML_Attribute_Def_Builder ()
{

}

ACEXML_Attributes_Def_Builder::~ACEXML_Attributes_Def_Builder ()
{

}

