// $Id: ErrorHandler.cpp 91673 2010-09-08 18:49:47Z johnnyw $

#include "ErrorHandler.h"

ACEXML_ErrorHandler::~ACEXML_ErrorHandler (void)
{
}
