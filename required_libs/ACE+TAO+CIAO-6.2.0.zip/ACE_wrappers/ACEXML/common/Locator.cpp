// $Id: Locator.cpp 91673 2010-09-08 18:49:47Z johnnyw $

#include "Locator.h"

ACEXML_Locator::~ACEXML_Locator (void)
{
}
