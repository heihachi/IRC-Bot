// $Id: Dispatcher_Impl.cpp 91670 2010-09-08 18:02:26Z johnnyw $

#include "Dispatcher_Impl.h"

#if ! defined (__ACE_INLINE__)
#include "Dispatcher_Impl.inl"
#endif /* __ACE_INLINE__ */

namespace Kokyu
{

//virtual - so don't inline
Dispatcher_Impl::~Dispatcher_Impl()
{
}

}
