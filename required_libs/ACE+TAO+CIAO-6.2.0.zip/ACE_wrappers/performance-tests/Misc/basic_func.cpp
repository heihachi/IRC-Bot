// $Id: basic_func.cpp 91670 2010-09-08 18:02:26Z johnnyw $

#include "basic_func.h"

int A, BB, C, D, E, F;

void
func ()
{
  DO_SOMETHING
}


void
Foo::func ()
{
  DO_SOMETHING
}


Foo_v::~Foo_v ()
{
}


void
Foo_v::func ()
{
  DO_SOMETHING
}


void
Foo_v::v_func ()
{
  DO_SOMETHING
}


void
Foo_d_v::v_func ()
{
  DO_SOMETHING
}


// EOF
